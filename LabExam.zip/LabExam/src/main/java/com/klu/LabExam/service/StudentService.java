package com.klu.LabExam.service;

import java.util.List;

import com.klu.LabExam.model.Student;

public interface StudentService {
	public String addStudent(Student student);
	public List<Student> findAllStudent();
	public Long countofStudent();
	
}
