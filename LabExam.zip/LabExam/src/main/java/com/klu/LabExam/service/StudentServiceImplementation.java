package com.klu.LabExam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klu.LabExam.model.Student;
import com.klu.LabExam.repository.StudentRepository;

@Service
public class StudentServiceImplementation implements StudentService {

	@Autowired
	private StudentRepository repository;
	
	@Override
	public String addStudent(Student student) {
		repository.save(student);
		return "added sucessfully";
	}

	@Override
	public List<Student> findAllStudent() {
		return repository.findAll();
	}

	@Override
	public Long countofStudent() {
		return repository.count();
	}

}
