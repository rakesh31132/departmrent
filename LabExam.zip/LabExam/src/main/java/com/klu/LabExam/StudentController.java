package com.klu.LabExam;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.klu.LabExam.model.Student;
import com.klu.LabExam.service.StudentService;

@Controller
public class StudentController {
    @Autowired
    private StudentService service;
    
    @GetMapping("/")
    public String home() {
        return "addStudent";
    }
    
    @PostMapping("/addStudent")
    public String postStudentData(@ModelAttribute Student student) {
        service.addStudent(student);
        return "redirect:/getAllStudents";
    }
    
    @GetMapping("/getAllStudents")
    public ModelAndView getAllStudentsdata() {
        ModelAndView mv = new ModelAndView();
        List<Student> data = service.findAllStudent();
        Long count = service.countofStudent();
        mv.addObject("data", data);
        mv.addObject("count", count);
        
        mv.setViewName("studentList");
        return mv;
    }
}
